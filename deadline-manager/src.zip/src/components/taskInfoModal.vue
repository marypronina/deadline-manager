<template>
    <div
        v-if="visible"
        class="task-info"
        :style="{ top: `${y}px`, left: `${x}px`, backgroundColor: color }"
        @mouseenter="$emit('cancel-close')"
        @mouseleave="$emit('start-close')"
    >
        <div class="modal-row-container">
            <p class="task-name" :style="{ color: chooseColor(color) }">
                {{ task.name }}
            </p>
            <span class="toggle-btn" @click="changeExpanded">
                <svg
                    :class="{ rotated: expanded }"
                    :fill="chooseColor(color)"
                    width="24"
                    height="24"
                    xmlns="http://www.w3.org/2000/svg"
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    style="transform: scaleY(0.7)"
                >
                    <path
                        d="M1.5 4l10.5 14 10.5-14 1.5 1.1-12 16-12-16 1.5-1.1z"
                    />
                </svg>
            </span>
        </div>

        <div v-if="expanded" class="task-details">
            <div class="deadline-container">
                <svg
                    :fill="chooseColor(color)"
                    width="24"
                    height="24"
                    xmlns="http://www.w3.org/2000/svg"
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                >
                    <path
                        d="M12 0c6.623 0 12 5.377 12 12s-5.377 12-12 12-12-5.377-12-12 5.377-12 12-12zm0 1c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11zm0 11h6v1h-7v-9h1v8z"
                    />
                </svg>

                <p :style="{ color: chooseColor(color) }">
                    {{ formatDate(task.finish_date) }}
                </p>
            </div>

            <p :style="{ color: chooseColor(color) }" class="task-description">
                {{ task.description }}
            </p>

            <p
                v-if="taskLinks?.length"
                class="links-info"
                :style="{ color: chooseColor(color) }"
            >
                Links:
            </p>
            <div class="links-container">
                <div v-for="link in taskLinks" :key="link.id">
                    <a
                        :href="link.url"
                        target="_blank"
                        class="link-info"
                        :style="{ color: chooseColor(color) }"
                        >{{ link.name }}</a
                    >
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { chooseColor } from "@/services/color";
import { formatDate } from "@/services/date";

export default {
    props: {
        visible: Boolean,
        x: Number,
        y: Number,
        color: String,
        task: Object,
        links: Array,
    },

    data() {
        return {
            chooseColor,
            formatDate,
            expanded: false,
        };
    },

    methods: {
        changeExpanded() {
            this.expanded = !this.expanded;
        },
    },

    computed: {
        taskLinks() {
            return this.links.filter((link) => link.task === this.task.id);
        },
    },
};
</script>

<style scoped>
.modal-row-container {
    padding: 0;
    min-width: 300px;

    display: flex;
    justify-content: space-between;
}

.toggle-btn {
    cursor: pointer;
}

.task-details {
    padding: 30px 0 10px 0;
}

svg {
    transition: transform 0.3s ease;
}

.rotated {
    transform: rotate(180deg) scaleY(0.7) !important;
}

.deadline-container {
    display: flex;
    gap: 20px;
    align-items: center;
}

.task-description {
    margin-top: 20px;
    font-weight: 300;
}

.links-info {
    margin: 20px 0 10px 0;
    font-weight: 500;
}

.links-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.link-info {
    font-weight: 300;

    cursor: pointer;
    text-decoration: underline;
}
</style>
