<script setup>
import Auth from '../components/auth.vue'
</script>


<template>
    <main>
        <Auth />
    </main>
  </template>