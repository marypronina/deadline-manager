<script setup>
import Home from '../components/home.vue'
</script>

<template>
    <main>
        <Home />
    </main>
</template>