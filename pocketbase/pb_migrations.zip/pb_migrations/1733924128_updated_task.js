/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1970519189")

  // add field
  collection.fields.addAt(4, new Field({
    "hidden": false,
    "id": "date2913981558",
    "max": "",
    "min": "",
    "name": "finish_date",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "date"
  }))

  // add field
  collection.fields.addAt(5, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_1423208309",
    "hidden": false,
    "id": "relation1841317061",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "group",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1970519189")

  // remove field
  collection.fields.removeById("date2913981558")

  // remove field
  collection.fields.removeById("relation1841317061")

  return app.save(collection)
})
