/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1423208309")

  // update collection data
  unmarshal({
    "name": "task_groups"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1423208309")

  // update collection data
  unmarshal({
    "name": "task_group"
  }, collection)

  return app.save(collection)
})
