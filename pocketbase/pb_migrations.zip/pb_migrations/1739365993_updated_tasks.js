/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1970519189")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id = group.user.id",
    "deleteRule": "@request.auth.id = group.user.id",
    "listRule": "@request.auth.id = group.user.id",
    "updateRule": "@request.auth.id = group.user.id",
    "viewRule": "@request.auth.id = group.user.id"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1970519189")

  // update collection data
  unmarshal({
    "createRule": "",
    "deleteRule": "",
    "listRule": "",
    "updateRule": "",
    "viewRule": ""
  }, collection)

  return app.save(collection)
})
