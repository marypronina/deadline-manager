/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_449060851")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id = task.group.user.id",
    "deleteRule": "@request.auth.id = task.group.user.id",
    "listRule": "@request.auth.id = task.group.user.id",
    "updateRule": "@request.auth.id = task.group.user.id",
    "viewRule": "@request.auth.id = task.group.user.id"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_449060851")

  // update collection data
  unmarshal({
    "createRule": "",
    "deleteRule": "",
    "listRule": "",
    "updateRule": "",
    "viewRule": ""
  }, collection)

  return app.save(collection)
})
